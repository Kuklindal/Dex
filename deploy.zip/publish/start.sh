#!/bin/bash
chmod +x DexScreener.dll
./DexScreener.dll